function Goodbye() {
    return(
        <div>
            <h1>
                Goodbye!!
            </h1>
        </div>
    )
}

export default Goodbye